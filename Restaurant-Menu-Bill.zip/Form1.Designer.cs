﻿namespace Lab7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelRestaurant = new System.Windows.Forms.Label();
            this.labelTableNumber = new System.Windows.Forms.Label();
            this.textInputTableNumber = new System.Windows.Forms.TextBox();
            this.groupBoxWaiterInformation = new System.Windows.Forms.GroupBox();
            this.textInputWaiterName = new System.Windows.Forms.TextBox();
            this.labelWaiterName = new System.Windows.Forms.Label();
            this.groupBoxMenuItems = new System.Windows.Forms.GroupBox();
            this.comboBoxDessert = new System.Windows.Forms.ComboBox();
            this.comboBoxMainCourse = new System.Windows.Forms.ComboBox();
            this.comboBoxAppetizer = new System.Windows.Forms.ComboBox();
            this.comboBoxBeverage = new System.Windows.Forms.ComboBox();
            this.labelDessert = new System.Windows.Forms.Label();
            this.labelMainCourse = new System.Windows.Forms.Label();
            this.labelAppetizer = new System.Windows.Forms.Label();
            this.labelBeverage = new System.Windows.Forms.Label();
            this.buttonClearBill = new System.Windows.Forms.Button();
            this.labelSubtotal = new System.Windows.Forms.Label();
            this.outputSubtotal = new System.Windows.Forms.TextBox();
            this.labelTax = new System.Windows.Forms.Label();
            this.outputTax = new System.Windows.Forms.TextBox();
            this.labelTotal = new System.Windows.Forms.Label();
            this.outputTotal = new System.Windows.Forms.TextBox();
            this.groupBoxWaiterInformation.SuspendLayout();
            this.groupBoxMenuItems.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelRestaurant
            // 
            this.labelRestaurant.AccessibleName = "labelRestaurant";
            this.labelRestaurant.AutoSize = true;
            this.labelRestaurant.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRestaurant.Location = new System.Drawing.Point(111, 26);
            this.labelRestaurant.Name = "labelRestaurant";
            this.labelRestaurant.Size = new System.Drawing.Size(99, 20);
            this.labelRestaurant.TabIndex = 0;
            this.labelRestaurant.Text = "Restaurant";
            // 
            // labelTableNumber
            // 
            this.labelTableNumber.AccessibleName = "labelTableNumber";
            this.labelTableNumber.AutoSize = true;
            this.labelTableNumber.Location = new System.Drawing.Point(20, 27);
            this.labelTableNumber.Name = "labelTableNumber";
            this.labelTableNumber.Size = new System.Drawing.Size(75, 13);
            this.labelTableNumber.TabIndex = 1;
            this.labelTableNumber.Text = "Table number:";
            // 
            // textInputTableNumber
            // 
            this.textInputTableNumber.AccessibleDescription = "textInputTableNumber";
            this.textInputTableNumber.Location = new System.Drawing.Point(164, 27);
            this.textInputTableNumber.Name = "textInputTableNumber";
            this.textInputTableNumber.Size = new System.Drawing.Size(68, 20);
            this.textInputTableNumber.TabIndex = 2;
            this.textInputTableNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBoxWaiterInformation
            // 
            this.groupBoxWaiterInformation.AccessibleName = "groupBoxWaiterInformation";
            this.groupBoxWaiterInformation.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxWaiterInformation.Controls.Add(this.textInputWaiterName);
            this.groupBoxWaiterInformation.Controls.Add(this.labelWaiterName);
            this.groupBoxWaiterInformation.Controls.Add(this.labelTableNumber);
            this.groupBoxWaiterInformation.Controls.Add(this.textInputTableNumber);
            this.groupBoxWaiterInformation.Location = new System.Drawing.Point(35, 66);
            this.groupBoxWaiterInformation.Name = "groupBoxWaiterInformation";
            this.groupBoxWaiterInformation.Size = new System.Drawing.Size(258, 87);
            this.groupBoxWaiterInformation.TabIndex = 3;
            this.groupBoxWaiterInformation.TabStop = false;
            this.groupBoxWaiterInformation.Text = "Waiter Information";
            this.groupBoxWaiterInformation.Enter += new System.EventHandler(this.groupBoxWaiterInformation_Enter);
            // 
            // textInputWaiterName
            // 
            this.textInputWaiterName.AccessibleName = "textInputWaiterName";
            this.textInputWaiterName.Location = new System.Drawing.Point(119, 53);
            this.textInputWaiterName.Name = "textInputWaiterName";
            this.textInputWaiterName.Size = new System.Drawing.Size(113, 20);
            this.textInputWaiterName.TabIndex = 4;
            this.textInputWaiterName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelWaiterName
            // 
            this.labelWaiterName.AccessibleName = "labelWaiterName";
            this.labelWaiterName.AutoSize = true;
            this.labelWaiterName.Location = new System.Drawing.Point(20, 57);
            this.labelWaiterName.Name = "labelWaiterName";
            this.labelWaiterName.Size = new System.Drawing.Size(77, 13);
            this.labelWaiterName.TabIndex = 3;
            this.labelWaiterName.Text = "Waiter\'s name:";
            // 
            // groupBoxMenuItems
            // 
            this.groupBoxMenuItems.AccessibleName = "groupBoxMenuItems";
            this.groupBoxMenuItems.Controls.Add(this.comboBoxDessert);
            this.groupBoxMenuItems.Controls.Add(this.comboBoxMainCourse);
            this.groupBoxMenuItems.Controls.Add(this.comboBoxAppetizer);
            this.groupBoxMenuItems.Controls.Add(this.comboBoxBeverage);
            this.groupBoxMenuItems.Controls.Add(this.labelDessert);
            this.groupBoxMenuItems.Controls.Add(this.labelMainCourse);
            this.groupBoxMenuItems.Controls.Add(this.labelAppetizer);
            this.groupBoxMenuItems.Controls.Add(this.labelBeverage);
            this.groupBoxMenuItems.Location = new System.Drawing.Point(35, 168);
            this.groupBoxMenuItems.Name = "groupBoxMenuItems";
            this.groupBoxMenuItems.Size = new System.Drawing.Size(258, 151);
            this.groupBoxMenuItems.TabIndex = 4;
            this.groupBoxMenuItems.TabStop = false;
            this.groupBoxMenuItems.Text = "Menu Items";
            // 
            // comboBoxDessert
            // 
            this.comboBoxDessert.AccessibleName = "comboBoxDessert";
            this.comboBoxDessert.FormattingEnabled = true;
            this.comboBoxDessert.Items.AddRange(new object[] {
            "Apple Pie",
            "Sundae",
            "Carrot Cake",
            "Mud Pie",
            "Apple Crisp"});
            this.comboBoxDessert.Location = new System.Drawing.Point(97, 115);
            this.comboBoxDessert.Name = "comboBoxDessert";
            this.comboBoxDessert.Size = new System.Drawing.Size(121, 21);
            this.comboBoxDessert.TabIndex = 7;
            this.comboBoxDessert.SelectedIndexChanged += new System.EventHandler(this.comboBoxDessert_SelectedIndexChanged);
            // 
            // comboBoxMainCourse
            // 
            this.comboBoxMainCourse.AccessibleName = "comboBoxMainCourse";
            this.comboBoxMainCourse.FormattingEnabled = true;
            this.comboBoxMainCourse.Items.AddRange(new object[] {
            "Seafood Alfredo",
            "Chicken Alfredo",
            "Chicken Picatta",
            "Turkey Club",
            "Lobster Pie",
            "Prime Rib",
            "Shrimp Scampi",
            "Turkey Dinner",
            "Stuffed Chicken"});
            this.comboBoxMainCourse.Location = new System.Drawing.Point(97, 88);
            this.comboBoxMainCourse.Name = "comboBoxMainCourse";
            this.comboBoxMainCourse.Size = new System.Drawing.Size(121, 21);
            this.comboBoxMainCourse.TabIndex = 6;
            this.comboBoxMainCourse.SelectedIndexChanged += new System.EventHandler(this.comboBoxMainCourse_SelectedIndexChanged);
            // 
            // comboBoxAppetizer
            // 
            this.comboBoxAppetizer.AccessibleName = "comboBoxAppetizer";
            this.comboBoxAppetizer.FormattingEnabled = true;
            this.comboBoxAppetizer.Items.AddRange(new object[] {
            "Buffalo Wings",
            "Buffalo Fingers",
            "Potato Skins",
            "Nachos",
            "Mushroom Caps",
            "Shrimp Cocktail",
            "Chips and Salsa"});
            this.comboBoxAppetizer.Location = new System.Drawing.Point(97, 61);
            this.comboBoxAppetizer.Name = "comboBoxAppetizer";
            this.comboBoxAppetizer.Size = new System.Drawing.Size(121, 21);
            this.comboBoxAppetizer.TabIndex = 5;
            this.comboBoxAppetizer.SelectedIndexChanged += new System.EventHandler(this.comboBoxAppetizer_SelectedIndexChanged);
            // 
            // comboBoxBeverage
            // 
            this.comboBoxBeverage.AccessibleName = "comboBoxBeverage";
            this.comboBoxBeverage.FormattingEnabled = true;
            this.comboBoxBeverage.Items.AddRange(new object[] {
            "Soda",
            "Tea",
            "Coffee",
            "Mineral Water",
            "Juice",
            "Milk"});
            this.comboBoxBeverage.Location = new System.Drawing.Point(97, 32);
            this.comboBoxBeverage.Name = "comboBoxBeverage";
            this.comboBoxBeverage.Size = new System.Drawing.Size(121, 21);
            this.comboBoxBeverage.TabIndex = 4;
            this.comboBoxBeverage.SelectedIndexChanged += new System.EventHandler(this.comboBoxBeverage_SelectedIndexChanged);
            // 
            // labelDessert
            // 
            this.labelDessert.AccessibleName = "labelDessert";
            this.labelDessert.AutoSize = true;
            this.labelDessert.Location = new System.Drawing.Point(25, 118);
            this.labelDessert.Name = "labelDessert";
            this.labelDessert.Size = new System.Drawing.Size(46, 13);
            this.labelDessert.TabIndex = 3;
            this.labelDessert.Text = "Dessert:";
            // 
            // labelMainCourse
            // 
            this.labelMainCourse.AccessibleName = "labelMainCourse";
            this.labelMainCourse.AutoSize = true;
            this.labelMainCourse.Location = new System.Drawing.Point(23, 91);
            this.labelMainCourse.Name = "labelMainCourse";
            this.labelMainCourse.Size = new System.Drawing.Size(68, 13);
            this.labelMainCourse.TabIndex = 2;
            this.labelMainCourse.Text = "Main course:";
            // 
            // labelAppetizer
            // 
            this.labelAppetizer.AccessibleName = "labelAppetizer";
            this.labelAppetizer.AutoSize = true;
            this.labelAppetizer.Location = new System.Drawing.Point(25, 64);
            this.labelAppetizer.Name = "labelAppetizer";
            this.labelAppetizer.Size = new System.Drawing.Size(54, 13);
            this.labelAppetizer.TabIndex = 1;
            this.labelAppetizer.Text = "Appetizer:";
            // 
            // labelBeverage
            // 
            this.labelBeverage.AccessibleName = "labelBeverage";
            this.labelBeverage.AutoSize = true;
            this.labelBeverage.Location = new System.Drawing.Point(23, 35);
            this.labelBeverage.Name = "labelBeverage";
            this.labelBeverage.Size = new System.Drawing.Size(56, 13);
            this.labelBeverage.TabIndex = 0;
            this.labelBeverage.Text = "Beverage:";
            // 
            // buttonClearBill
            // 
            this.buttonClearBill.AccessibleName = "buttonClearBill";
            this.buttonClearBill.Location = new System.Drawing.Point(116, 340);
            this.buttonClearBill.Name = "buttonClearBill";
            this.buttonClearBill.Size = new System.Drawing.Size(94, 23);
            this.buttonClearBill.TabIndex = 5;
            this.buttonClearBill.Text = "Clear Bill";
            this.buttonClearBill.UseVisualStyleBackColor = true;
            this.buttonClearBill.Click += new System.EventHandler(this.buttonClearBill_Click);
            // 
            // labelSubtotal
            // 
            this.labelSubtotal.AccessibleName = "labelSubtotal";
            this.labelSubtotal.AutoSize = true;
            this.labelSubtotal.Location = new System.Drawing.Point(83, 383);
            this.labelSubtotal.Name = "labelSubtotal";
            this.labelSubtotal.Size = new System.Drawing.Size(49, 13);
            this.labelSubtotal.TabIndex = 6;
            this.labelSubtotal.Text = "Subtotal:";
            // 
            // outputSubtotal
            // 
            this.outputSubtotal.AccessibleName = "outputSubtotal";
            this.outputSubtotal.Location = new System.Drawing.Point(138, 380);
            this.outputSubtotal.Name = "outputSubtotal";
            this.outputSubtotal.ReadOnly = true;
            this.outputSubtotal.Size = new System.Drawing.Size(83, 20);
            this.outputSubtotal.TabIndex = 7;
            this.outputSubtotal.Text = "$0.00";
            this.outputSubtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelTax
            // 
            this.labelTax.AccessibleName = "labelTax";
            this.labelTax.AutoSize = true;
            this.labelTax.Location = new System.Drawing.Point(83, 416);
            this.labelTax.Name = "labelTax";
            this.labelTax.Size = new System.Drawing.Size(28, 13);
            this.labelTax.TabIndex = 8;
            this.labelTax.Text = "Tax:";
            // 
            // outputTax
            // 
            this.outputTax.AccessibleName = "outputTax";
            this.outputTax.Location = new System.Drawing.Point(138, 413);
            this.outputTax.Name = "outputTax";
            this.outputTax.ReadOnly = true;
            this.outputTax.Size = new System.Drawing.Size(83, 20);
            this.outputTax.TabIndex = 9;
            this.outputTax.Text = "$0.00";
            this.outputTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelTotal
            // 
            this.labelTotal.AccessibleName = "labelTotal";
            this.labelTotal.AutoSize = true;
            this.labelTotal.Location = new System.Drawing.Point(83, 448);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(34, 13);
            this.labelTotal.TabIndex = 10;
            this.labelTotal.Text = "Total:";
            // 
            // outputTotal
            // 
            this.outputTotal.AccessibleName = "outputTotal";
            this.outputTotal.Location = new System.Drawing.Point(138, 445);
            this.outputTotal.Name = "outputTotal";
            this.outputTotal.ReadOnly = true;
            this.outputTotal.Size = new System.Drawing.Size(83, 20);
            this.outputTotal.TabIndex = 11;
            this.outputTotal.Text = "$0.00";
            this.outputTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 477);
            this.Controls.Add(this.outputTotal);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.outputTax);
            this.Controls.Add(this.labelTax);
            this.Controls.Add(this.outputSubtotal);
            this.Controls.Add(this.labelSubtotal);
            this.Controls.Add(this.buttonClearBill);
            this.Controls.Add(this.groupBoxMenuItems);
            this.Controls.Add(this.groupBoxWaiterInformation);
            this.Controls.Add(this.labelRestaurant);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBoxWaiterInformation.ResumeLayout(false);
            this.groupBoxWaiterInformation.PerformLayout();
            this.groupBoxMenuItems.ResumeLayout(false);
            this.groupBoxMenuItems.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelRestaurant;
        private System.Windows.Forms.Label labelTableNumber;
        private System.Windows.Forms.TextBox textInputTableNumber;
        private System.Windows.Forms.GroupBox groupBoxWaiterInformation;
        private System.Windows.Forms.TextBox textInputWaiterName;
        private System.Windows.Forms.Label labelWaiterName;
        private System.Windows.Forms.GroupBox groupBoxMenuItems;
        private System.Windows.Forms.ComboBox comboBoxBeverage;
        private System.Windows.Forms.Label labelDessert;
        private System.Windows.Forms.Label labelMainCourse;
        private System.Windows.Forms.Label labelAppetizer;
        private System.Windows.Forms.Label labelBeverage;
        private System.Windows.Forms.ComboBox comboBoxAppetizer;
        private System.Windows.Forms.ComboBox comboBoxDessert;
        private System.Windows.Forms.ComboBox comboBoxMainCourse;
        private System.Windows.Forms.Button buttonClearBill;
        private System.Windows.Forms.Label labelSubtotal;
        private System.Windows.Forms.TextBox outputSubtotal;
        private System.Windows.Forms.Label labelTax;
        private System.Windows.Forms.TextBox outputTax;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.TextBox outputTotal;
    }
}

