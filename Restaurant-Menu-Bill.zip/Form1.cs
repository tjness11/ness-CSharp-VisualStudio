﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBoxWaiterInformation_Enter(object sender, EventArgs e)
        {

        }

        private void comboBoxBeverage_SelectedIndexChanged(object sender, EventArgs e)
        {
            calculateSubtotal();
        }

        private void comboBoxAppetizer_SelectedIndexChanged(object sender, EventArgs e)
        {
            calculateSubtotal();
        }

        private void comboBoxMainCourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            calculateSubtotal();
        }

        private void comboBoxDessert_SelectedIndexChanged(object sender, EventArgs e)
        {
            calculateSubtotal();
        }

        private void calculateSubtotal()
        {
            string beverageChoice = comboBoxBeverage.Text;
            string appetizerChoice = comboBoxAppetizer.Text;
            string mainCourseChoice = comboBoxMainCourse.Text;
            string dessertChoice = comboBoxDessert.Text;

            double total = 0;

            //calculating beverage choice
            for (int x = 0; x < Restaurant.RestaurantData.beverages.Length / 2; x++)
            {
                if (beverageChoice == Restaurant.RestaurantData.beverages[x, 0])
                {
                    total += Double.Parse(Restaurant.RestaurantData.beverages[x, 1]);
                }
            }

            //calculating appetizer choice
            for (int x = 0; x < Restaurant.RestaurantData.appetizers.Length / 2; x++)
            {
                if (appetizerChoice == Restaurant.RestaurantData.appetizers[x, 0])
                {
                    total += Double.Parse(Restaurant.RestaurantData.appetizers[x, 1]);
                }
            }

            //calculating main course choice
            for (int x = 0; x < Restaurant.RestaurantData.mainCourses.Length / 2; x++)
            {
                if (mainCourseChoice == Restaurant.RestaurantData.mainCourses[x, 0])
                {
                    total += Double.Parse(Restaurant.RestaurantData.mainCourses[x, 1]);
                }
            }

            //calculating dessert choice
            for (int x = 0; x < Restaurant.RestaurantData.desserts.Length / 2; x++)
            {
                if (dessertChoice == Restaurant.RestaurantData.desserts[x, 0])
                {
                    total += Double.Parse(Restaurant.RestaurantData.desserts[x, 1]);
                }
            }

            string totalString = String.Format("{0:0.00}", total);
            outputSubtotal.Text = "$" + totalString;
            calculateTax(total);

        }

        private void calculateTax(double subtotal)
        {
            double tax = 0.05;
            double taxTotal = 0;

            taxTotal = subtotal * tax;

            string totalTaxString = String.Format("{0:0.00}", taxTotal);
            outputTax.Text = "$" + totalTaxString;

            calculateTotal(subtotal, taxTotal);

        }

        private void calculateTotal(double subtotal, double tax)
        {
            double total = subtotal + tax;

            string totalString = String.Format("{0:0.00}", total);
            outputTotal.Text = "$" + totalString;

        }

        private void buttonClearBill_Click(object sender, EventArgs e)
        {
            textInputTableNumber.Text = "";
            textInputWaiterName.Text = "";
            comboBoxBeverage.Text = "";
            comboBoxAppetizer.Text = "";
            comboBoxMainCourse.Text = "";
            comboBoxDessert.Text = "";
            calculateSubtotal();
        }
    }
}
