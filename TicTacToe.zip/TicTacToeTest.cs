
// Play a game of Tic Tac Toe

using Lab4;
using System;

public class TicTacToeTest
{
   public static void Main(string[] args)
   {
        TicTacToe game = new TicTacToe();
        game.PrintBoard();
        game.Play();
        Console.ReadLine();
        Environment.Exit(1);

   }   


} 