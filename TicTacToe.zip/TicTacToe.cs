﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    class TicTacToe
    {
        public static int[,] board = new int[3, 3];
        public static int playersTurn = 1;

        public void PrintBoard()
        {
            Console.WriteLine(" _______________________");
            for (var row = 0; row < board.GetLength(0); ++row)
            {
                Console.WriteLine("|       |       |       |");
                for (var column = 0; column < board.GetLength(1); ++column)
                {
                    Console.Write($"{"|   " + board[row, column] + "   "}"); 
                }
                Console.WriteLine("|");
                Console.WriteLine("|_______|_______|_______|");
            }
        }

        public void Play()
        {
            int row = 0;
            int column = 0;
            bool empty = false;

            while (!checkWinner())
            {
                empty = false;
                Console.WriteLine("Player " + playersTurn + "'s turn.");
                while (!empty)
                {
                    row = getValidInput("row");
                    column = getValidInput("column");
                    empty = checkIfEmpty(row, column);
                }


                board[row, column] = playersTurn;

                PrintBoard();

                changePlayerTurn();
            }

            changePlayerTurn();

            Console.WriteLine("Player " + playersTurn + " wins!");
       
        }

        private int getValidInput(String location)
        {
            bool validUserInput = false;
            int rowOrColumn = 10; //Picked a number over 3 so it returns false
            while (validUserInput == false)
            {
                try
                {
                    Console.Write("Player " + playersTurn + ": Enter " + location + " (0 <= " + location + " < 3): ");
                    rowOrColumn = int.Parse(Console.ReadLine());
                }
                catch (Exception)
                {}
                if (rowOrColumn < 0 || rowOrColumn > 2)
                    Console.WriteLine("Invalid " + location + " number!");
                else
                    validUserInput = true;
            }

            return rowOrColumn;
        }

        private bool checkWinner()
        {
            bool winner = false;
            //I put the last and loop at the end of these statements to make sure all 0's didn't count
            for (var row = 0; row < board.GetLength(0); ++row)
            {
                if (board[row, 0] == board[row, 1] && board[row, 1] == board[row, 2] && board[row, 2] != 0)
                    winner = true;
            }
            for (var column = 0; column < board.GetLength(0); ++column)
            {
                if (board[0, column] == board[1, column] && board[1, column] == board[2, column] && board[column, 2] != 0)
                    winner = true;
            }
            if (board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2] && board[2, 2] != 0)
                winner = true;
            else if (board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0] && board[2, 0] != 0)
                winner = true;
            return winner;
        }

        private void changePlayerTurn()
        {
            //Changes the player turn after each guess
            if (playersTurn == 1)
                playersTurn = 2;
            else
                playersTurn = 1;
        }

        private bool checkIfEmpty(int row, int column)
        {
            bool empty;
            if (board[row, column] == 0)
                empty = true;
            else
            {
                empty = false;
                Console.WriteLine("This position was already used by your opponent, try again.");
            }

            return empty;
        }
    }
}
