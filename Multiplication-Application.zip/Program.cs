﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Boolean keepGoing = true;
            while (keepGoing)
            {
                Random rnd = new Random();
                int digit1 = rnd.Next(0, 10);
                int digit2 = rnd.Next(0, 10);
                int numberAnswer = 0;
                Boolean correct = false;
                string answer;
                int total = digit1 * digit2;
                while (!correct)
                {
                    Console.WriteLine("How much is " + digit1 + " times " + digit2);
                    Console.WriteLine("Enter you answer (-1 to exit)");
                    answer = Console.ReadLine();
                    numberAnswer = Convert.ToInt32(answer);
                    if (numberAnswer == total)
                    {
                        Console.WriteLine(correctAnswer());
                        correct = true;
                    }
                    else if (numberAnswer == -1)
                        Environment.Exit(0);
                    else
                        Console.WriteLine(wrongAnswer());
                }
            }
        }

        public static String correctAnswer()
        {
            var list = new List<string> { "Very good!", "Excellent", "Nice work!", "Keep up the good work!" };
            Random rnd = new Random();
            String randomString;
            int randomInt = rnd.Next(0, 4);
            randomString = list[randomInt];
            return randomString;
        }

        public static String wrongAnswer()
        {
            var list = new List<string> { "No.Please Try again.", "Wrong. Try once more.", "Don't give up!", "No. Keep trying." };
            Random rnd = new Random();
            String randomString;
            int randomInt = rnd.Next(0, 4);
            randomString = list[randomInt];
            return randomString;
        }
    }
}
        
    

